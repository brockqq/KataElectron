const { ipcRenderer } = require('electron');

ipcRenderer.on('open-epub', (event, filePath) => {
  console.log("EPUB 檔案路徑收到：", filePath);
  const book = ePub(filePath);
  const rendition = book.renderTo("viewer", {
    width: "100%",
    height: "100%",
  });
  rendition.display();
});